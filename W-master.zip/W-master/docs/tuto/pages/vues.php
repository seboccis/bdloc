<h2>Les vues</h2>
<h3>À quoi servent les vues ? </h3>
<h3>Comment créer un nouveau fichier de vue ? </h3>
<h3>Les layouts et l'héritage</h3>
<h3>Les méthodes disponibles</h3>
		$this->e()
		$this->url()
		$this->assetUrl()
	<h3>Les données disponibles</h3>
		$user

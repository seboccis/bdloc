<h2>Les contrôleurs</h2>
	<h3>À quoi servent les contrôleurs ?</h3>
	<h3>Comment créer un contrôleur ?</h3>
		La classe W\Controller\Controller
	<h3>Créer une action</h3>
		Recevoir les paramètres dynamiques d'URL
		Finalité d'une action
	<h3>Les méthodes héritées disponibles</h3>
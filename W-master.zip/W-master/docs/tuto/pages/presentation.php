<h2>Présentation</h2>
<p>W est un framework minimaliste et pédagogique. Il suit les structures et les grand thèmes des frameworks PHP OO MVC actuels, tout en en facilitant l'approche.</p>

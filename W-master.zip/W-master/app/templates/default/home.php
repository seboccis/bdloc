<?php $this->layout('layout', ['title' => 'Accueil !']) ?>

<?php $this->start('main_content') ?>
	<h2>Let's code.</h2>
	
<?php $this->stop('main_content') ?>

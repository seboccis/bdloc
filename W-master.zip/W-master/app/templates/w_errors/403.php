<?php $this->layout('layout', ['title' => 'Créer un nouvel administrateur']) ?>

<?php $this->start('main_content'); ?>
<h1>403. Nothing to see here.</h1>
<?php $this->stop('main_content'); ?>

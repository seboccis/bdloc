<?php
	
	$w_routes = array(
		['GET', '/', 'Default#home', 'home'],
	);
### Répertoire app/Manager

Ce répertoire contient vos différents gestionnaires de données. Vous pouvez y créer des sous-dossiers sans problème, du moment que les espaces de noms de vos gestionnaires collent à la structure de ces dossiers. 

Tous vos gestionnaires devraient hériter de \W\Manager\Manager, le gestionnaire de données de base du framework W. Votre UserManager pourrait toutefois plutôt hériter de \W\Manager\UserManager, afin de bénéficier de quelques méthodes supplémentaires. 